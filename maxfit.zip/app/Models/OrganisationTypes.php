<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrganisationTypes extends Model
{
    protected $table = 'organisation_types';
    protected $fillable = ['name'];

   
}

$('.select2').select2({
    theme: 'bootstrap-5',
    width: '100%'
});
$('.datatable').DataTable({
    lengthChange: false
});